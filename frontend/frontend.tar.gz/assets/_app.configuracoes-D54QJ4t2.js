const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/index-DU09WJwA.js","assets/index-DbotRf-Q.css"])))=>i.map(i=>d[i]);
import { r as reactExports, v as settingsApi, A as toast, k as jsxRuntimeExports, _ as __vitePreload, m as profileApi, G as whatsappApi } from "./index-DU09WJwA.js";
import { P as PageHeader, B as Bell } from "./AppShell-B-Yqm6fM.js";
import { U as User } from "./user-BmX6MCSL.js";
import { M as MessageCircle } from "./message-circle-DV6-LHLJ.js";
import { c as createLucideIcon } from "./createLucideIcon-DhMEA509.js";
import { L as LoaderCircle } from "./loader-circle-F4UN_tCW.js";
import { C as CircleAlert } from "./circle-alert-D8zQxJLf.js";
import "./sparkles-Czkx5i21.js";
const __iconNode$2 = [
  ["circle", { cx: "12", cy: "12", r: "10", key: "1mglay" }],
  ["path", { d: "m9 12 2 2 4-4", key: "dzmm74" }]
];
const CircleCheck = createLucideIcon("circle-check", __iconNode$2);
const __iconNode$1 = [
  ["path", { d: "M10 8h4", key: "1sr2af" }],
  ["path", { d: "M12 21v-9", key: "17s77i" }],
  ["path", { d: "M12 8V3", key: "13r4qs" }],
  ["path", { d: "M17 16h4", key: "h1uq16" }],
  ["path", { d: "M19 12V3", key: "o1uvq1" }],
  ["path", { d: "M19 21v-5", key: "qua636" }],
  ["path", { d: "M3 14h4", key: "bcjad9" }],
  ["path", { d: "M5 10V3", key: "cb8scm" }],
  ["path", { d: "M5 21v-7", key: "1w1uti" }]
];
const SlidersVertical = createLucideIcon("sliders-vertical", __iconNode$1);
const __iconNode = [
  ["path", { d: "M12 20h.01", key: "zekei9" }],
  ["path", { d: "M8.5 16.429a5 5 0 0 1 7 0", key: "1bycff" }],
  ["path", { d: "M5 12.859a10 10 0 0 1 5.17-2.69", key: "1dl1wf" }],
  ["path", { d: "M19 12.859a10 10 0 0 0-2.007-1.523", key: "4k23kn" }],
  ["path", { d: "M2 8.82a15 15 0 0 1 4.177-2.643", key: "1grhjp" }],
  ["path", { d: "M22 8.82a15 15 0 0 0-11.288-3.764", key: "z3jwby" }],
  ["path", { d: "m2 2 20 20", key: "1ooewy" }]
];
const WifiOff = createLucideIcon("wifi-off", __iconNode);
const sections = [{
  id: "perfil",
  label: "Perfil",
  icon: User
}, {
  id: "whatsapp",
  label: "WhatsApp",
  icon: MessageCircle
}, {
  id: "preferencias",
  label: "Preferências",
  icon: SlidersVertical
}, {
  id: "notificacoes",
  label: "Notificações",
  icon: Bell
}];
function SettingsPage() {
  const [active, setActive] = reactExports.useState("perfil");
  const [settings, setSettings] = reactExports.useState(null);
  const [loadingSettings, setLoadingSettings] = reactExports.useState(true);
  reactExports.useEffect(() => {
    settingsApi.get().then(setSettings).catch(() => toast.error("Erro ao carregar configurações")).finally(() => setLoadingSettings(false));
  }, []);
  const saveSettings = async (updated) => {
    if (!settings) return;
    const merged = {
      ...settings,
      ...updated
    };
    setSettings(merged);
    try {
      const saved = await settingsApi.update(merged);
      setSettings(saved);
      toast.success("Configurações salvas!");
    } catch {
      toast.error("Erro ao salvar configurações");
    }
  };
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mx-auto max-w-7xl", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx(PageHeader, { title: "Configurações", subtitle: "Personalize sua experiência no StudioFlow." }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid grid-cols-1 gap-8 lg:grid-cols-[220px_1fr]", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("nav", { className: "space-y-1", children: sections.map((s) => /* @__PURE__ */ jsxRuntimeExports.jsxs("button", { onClick: () => setActive(s.id), className: `flex w-full items-center gap-3 rounded-xl px-3 py-2.5 text-left text-sm font-medium transition-all ${active === s.id ? "bg-brand-100 text-brand-600" : "text-brand-900/60 hover:bg-brand-50"}`, children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(s.icon, { className: "size-4" }),
        s.label
      ] }, s.id)) }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "rounded-3xl border border-border bg-card p-6 shadow-sm md:p-8", children: loadingSettings ? /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex items-center justify-center py-16 text-brand-900/40", children: /* @__PURE__ */ jsxRuntimeExports.jsx(LoaderCircle, { className: "size-6 animate-spin" }) }) : /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
        active === "perfil" && /* @__PURE__ */ jsxRuntimeExports.jsx(PerfilSection, {}),
        active === "whatsapp" && settings && /* @__PURE__ */ jsxRuntimeExports.jsx(WhatsAppSection, { settings, onChange: saveSettings }),
        active === "preferencias" && settings && /* @__PURE__ */ jsxRuntimeExports.jsx(PreferencesSection, { settings, onChange: saveSettings }),
        active === "notificacoes" && settings && /* @__PURE__ */ jsxRuntimeExports.jsx(NotificationsSection, { settings, onChange: saveSettings })
      ] }) })
    ] })
  ] });
}
function PerfilSection() {
  const [user, setUser] = reactExports.useState(null);
  const [name, setName] = reactExports.useState("");
  const [email, setEmail] = reactExports.useState("");
  const [studio, setStudio] = reactExports.useState("");
  const [password, setPassword] = reactExports.useState("");
  const [loading, setLoading] = reactExports.useState(false);
  const [fetching, setFetching] = reactExports.useState(true);
  reactExports.useEffect(() => {
    __vitePreload(async () => {
      const { authApi } = await import("./index-DU09WJwA.js").then((n) => n.a);
      return { authApi };
    }, true ? __vite__mapDeps([0,1]) : void 0).then(({
      authApi
    }) => authApi.me()).then((u) => {
      setUser(u);
      setName(u.name);
      setEmail(u.email);
      setStudio(u.studio_name);
    }).catch(() => toast.error("Erro ao carregar perfil")).finally(() => setFetching(false));
  }, []);
  const save = async (e) => {
    e.preventDefault();
    setLoading(true);
    try {
      const updated = await profileApi.update({
        name,
        email,
        studio_name: studio,
        ...password ? {
          password
        } : {}
      });
      setUser(updated);
      setPassword("");
      toast.success("Perfil atualizado!");
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Erro ao salvar");
    } finally {
      setLoading(false);
    }
  };
  if (fetching) {
    return /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex items-center justify-center py-16 text-brand-900/40", children: /* @__PURE__ */ jsxRuntimeExports.jsx(LoaderCircle, { className: "size-6 animate-spin" }) });
  }
  const initials = name.split(" ").map((n) => n[0]).slice(0, 2).join("").toUpperCase();
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("form", { onSubmit: save, children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx("h2", { className: "mb-1 font-serif text-2xl font-semibold", children: "Perfil" }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "mb-8 text-sm text-brand-900/50", children: "Informações do seu estúdio e da sua conta." }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mb-8 flex items-center gap-5", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex size-20 items-center justify-center rounded-full bg-brand-100 font-serif text-2xl font-semibold text-brand-600", children: initials }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-sm font-semibold", children: user?.name }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "mt-1 text-xs text-brand-900/50", children: user?.email })
      ] })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-4", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(Field, { label: "Nome", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Input, { value: name, onChange: setName }) }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(Field, { label: "Nome do estúdio", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Input, { value: studio, onChange: setStudio }) }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(Field, { label: "E-mail", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Input, { value: email, onChange: setEmail, type: "email" }) }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(Field, { label: "Nova senha (deixe em branco para manter)", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Input, { value: password, onChange: setPassword, type: "password", placeholder: "••••••••" }) })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("button", { type: "submit", disabled: loading, className: "mt-8 flex h-11 items-center justify-center gap-2 rounded-xl bg-brand-600 px-6 text-sm font-semibold text-white shadow-lg shadow-brand-600/20 hover:bg-brand-500 disabled:opacity-70", children: [
      loading && /* @__PURE__ */ jsxRuntimeExports.jsx(LoaderCircle, { className: "size-4 animate-spin" }),
      loading ? "Salvando..." : "Salvar alterações"
    ] })
  ] });
}
const DEFAULT_CONFIRMATION = `Oi {nome}! Agendamento confirmado 🤎

*{servico}*
{data} às {horario}

Qualquer coisa é só me chamar!`;
const DEFAULT_REMINDER = `Oi {nome}! Passando pra lembrar do seu horário amanhã 🤎

*{servico}* às {horario}

Me responde *SIM* pra confirmar ou *NÃO* pra cancelar`;
const DEFAULT_RESCHEDULE = `Oi {nome}! Precisei reagendar o seu horário 🤎

*{servico}*
{data} às {horario}

Qualquer dúvida é só falar!`;
function WhatsAppConnection() {
  const [status, setStatus] = reactExports.useState("loading");
  const [qr, setQr] = reactExports.useState(null);
  const [connecting, setConnecting] = reactExports.useState(false);
  const [disconnecting, setDisconnecting] = reactExports.useState(false);
  reactExports.useEffect(() => {
    whatsappApi.getStatus().then((s) => setStatus(s.connected ? "connected" : "disconnected")).catch(() => setStatus("disconnected"));
  }, []);
  reactExports.useEffect(() => {
    if (!qr) return;
    const id = setInterval(async () => {
      try {
        const s = await whatsappApi.getStatus();
        if (s.connected) {
          setQr(null);
          setStatus("connected");
          setConnecting(false);
          toast.success("WhatsApp conectado!");
        }
      } catch {
      }
    }, 3e3);
    return () => clearInterval(id);
  }, [qr]);
  async function handleConnect() {
    setConnecting(true);
    try {
      await whatsappApi.connect();
      await new Promise((r) => setTimeout(r, 2e3));
      const qrData = await whatsappApi.getQrCode();
      const base64 = qrData.base64 ?? "";
      if (!base64) {
        const s = await whatsappApi.getStatus();
        if (s.connected) {
          setStatus("connected");
          setConnecting(false);
          return;
        }
        toast.error("Não foi possível gerar o QR code. Tente novamente.");
        setConnecting(false);
        return;
      }
      setQr(base64.startsWith("data:") ? base64 : `data:image/png;base64,${base64}`);
    } catch {
      toast.error("Erro ao iniciar conexão");
      setConnecting(false);
    }
  }
  async function handleDisconnect() {
    setDisconnecting(true);
    try {
      await whatsappApi.deleteInstance();
      setStatus("disconnected");
      setQr(null);
      toast.success("WhatsApp desconectado");
    } catch {
      toast.error("Erro ao desconectar");
    } finally {
      setDisconnecting(false);
    }
  }
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mb-10 rounded-2xl border border-border bg-card p-6", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: "mb-1 font-semibold", children: "Conexão WhatsApp" }),
    status === "loading" && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2 text-sm text-brand-900/50", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(LoaderCircle, { className: "size-4 animate-spin" }),
      " Verificando..."
    ] }),
    status === "connected" && !qr && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2 text-sm text-emerald-600", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(CircleCheck, { className: "size-4" }),
        " Conectado"
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("button", { onClick: handleDisconnect, disabled: disconnecting, className: "flex items-center gap-1.5 rounded-xl border border-rose-200 px-4 py-2 text-xs font-medium text-rose-500 hover:bg-rose-50 disabled:opacity-60", children: [
        disconnecting && /* @__PURE__ */ jsxRuntimeExports.jsx(LoaderCircle, { className: "size-3 animate-spin" }),
        "Desconectar"
      ] })
    ] }),
    status === "disconnected" && !qr && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2 text-sm text-brand-900/40", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(WifiOff, { className: "size-4" }),
        " Não conectado"
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("button", { onClick: handleConnect, disabled: connecting, className: "flex items-center gap-1.5 rounded-xl bg-brand-600 px-4 py-2 text-xs font-semibold text-white shadow shadow-brand-600/20 hover:bg-brand-500 disabled:opacity-60", children: [
        connecting && /* @__PURE__ */ jsxRuntimeExports.jsx(LoaderCircle, { className: "size-3 animate-spin" }),
        connecting ? "Aguarde..." : "Conectar WhatsApp"
      ] })
    ] }),
    qr && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mt-4 flex flex-col items-center gap-3", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-sm text-brand-900/60", children: "Escaneie com o WhatsApp do celular" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("img", { src: qr, alt: "QR Code WhatsApp", className: "size-56 rounded-xl border border-border" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-brand-900/40", children: "Aguardando leitura..." })
    ] })
  ] });
}
function WhatsAppSection({
  settings,
  onChange
}) {
  const [confirmation, setConfirmation] = reactExports.useState(settings.wa_msg_confirmation ?? DEFAULT_CONFIRMATION);
  const [reminder, setReminder] = reactExports.useState(settings.wa_msg_reminder ?? DEFAULT_REMINDER);
  const [reschedule, setReschedule] = reactExports.useState(settings.wa_msg_reschedule ?? DEFAULT_RESCHEDULE);
  const [saving, setSaving] = reactExports.useState(false);
  const reminderMissingSim = !/\bsim\b/i.test(reminder);
  const reminderMissingNao = !/\bn[aã]o\b/i.test(reminder);
  async function save() {
    setSaving(true);
    try {
      await onChange({
        wa_msg_confirmation: confirmation || null,
        wa_msg_reminder: reminder || null,
        wa_msg_reschedule: reschedule || null
      });
    } finally {
      setSaving(false);
    }
  }
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx("h2", { className: "mb-1 font-serif text-2xl font-semibold", children: "WhatsApp" }),
    /* @__PURE__ */ jsxRuntimeExports.jsx(WhatsAppConnection, {}),
    /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: "mb-1 font-semibold", children: "Mensagens automáticas" }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "mb-2 text-sm text-brand-900/50", children: "Personalize o texto enviado automaticamente para suas clientes." }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { className: "mb-8 text-xs text-brand-900/40", children: [
      "Variáveis disponíveis: ",
      /* @__PURE__ */ jsxRuntimeExports.jsx("code", { className: "rounded bg-brand-50 px-1", children: "{nome}" }),
      " ",
      /* @__PURE__ */ jsxRuntimeExports.jsx("code", { className: "rounded bg-brand-50 px-1", children: "{servico}" }),
      " ",
      /* @__PURE__ */ jsxRuntimeExports.jsx("code", { className: "rounded bg-brand-50 px-1", children: "{data}" }),
      " ",
      /* @__PURE__ */ jsxRuntimeExports.jsx("code", { className: "rounded bg-brand-50 px-1", children: "{horario}" })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-6", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(Field, { label: "Confirmação de agendamento", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Textarea, { value: confirmation, onChange: setConfirmation, rows: 4 }) }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs(Field, { label: "Lembrete 12h antes", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(Textarea, { value: reminder, onChange: setReminder, rows: 4 }),
        (reminderMissingSim || reminderMissingNao) && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mt-2 flex items-start gap-2 rounded-xl bg-amber-50 p-3 text-xs text-amber-700", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(CircleAlert, { className: "mt-0.5 size-3.5 shrink-0" }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { children: [
            "O lembrete precisa conter ",
            /* @__PURE__ */ jsxRuntimeExports.jsx("strong", { children: "SIM" }),
            " e ",
            /* @__PURE__ */ jsxRuntimeExports.jsx("strong", { children: "NÃO" }),
            " para que o sistema reconheça a resposta da cliente."
          ] })
        ] })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(Field, { label: "Reagendamento", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Textarea, { value: reschedule, onChange: setReschedule, rows: 4 }) })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("button", { onClick: save, disabled: saving, className: "mt-8 flex h-11 items-center justify-center gap-2 rounded-xl bg-brand-600 px-6 text-sm font-semibold text-white shadow-lg shadow-brand-600/20 hover:bg-brand-500 disabled:opacity-70", children: [
      saving && /* @__PURE__ */ jsxRuntimeExports.jsx(LoaderCircle, { className: "size-4 animate-spin" }),
      saving ? "Salvando..." : "Salvar mensagens"
    ] })
  ] });
}
function PreferencesSection({
  settings,
  onChange
}) {
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx("h2", { className: "mb-1 font-serif text-2xl font-semibold", children: "Preferências" }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "mb-8 text-sm text-brand-900/50", children: "Ajuste o funcionamento do StudioFlow." }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-3", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(Toggle, { label: "Tema escuro automático", value: !!settings.pref_dark_auto, onChange: (v) => onChange({
        pref_dark_auto: v ? 1 : 0
      }) }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(Toggle, { label: "Mostrar valores na agenda", value: !!settings.pref_show_values, onChange: (v) => onChange({
        pref_show_values: v ? 1 : 0
      }) }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(Toggle, { label: "Bloquear horários de almoço", value: !!settings.pref_block_lunch, onChange: (v) => onChange({
        pref_block_lunch: v ? 1 : 0
      }) }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(Toggle, { label: "Permitir agendamentos no domingo", value: !!settings.pref_allow_sunday, onChange: (v) => onChange({
        pref_allow_sunday: v ? 1 : 0
      }) })
    ] })
  ] });
}
function NotificationsSection({
  settings,
  onChange
}) {
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx("h2", { className: "mb-1 font-serif text-2xl font-semibold", children: "Notificações" }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "mb-8 text-sm text-brand-900/50", children: "Escolha quando quer ser avisada." }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-3", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(Toggle, { label: "Novo agendamento", value: !!settings.notify_new, onChange: (v) => onChange({
        notify_new: v ? 1 : 0
      }) }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(Toggle, { label: "Cancelamento", value: !!settings.notify_cancel, onChange: (v) => onChange({
        notify_cancel: v ? 1 : 0
      }) }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(Toggle, { label: "Confirmação de cliente", value: !!settings.notify_confirm, onChange: (v) => onChange({
        notify_confirm: v ? 1 : 0
      }) }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(Toggle, { label: "Resumo diário por e-mail", value: !!settings.notify_daily_email, onChange: (v) => onChange({
        notify_daily_email: v ? 1 : 0
      }) }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(Toggle, { label: "Relatório semanal", value: !!settings.notify_weekly, onChange: (v) => onChange({
        notify_weekly: v ? 1 : 0
      }) })
    ] })
  ] });
}
function Toggle({
  label,
  value,
  onChange
}) {
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("button", { onClick: () => onChange(!value), className: "flex w-full items-center justify-between rounded-2xl border border-border bg-card p-4 text-left hover:bg-brand-50", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-sm font-medium", children: label }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: `relative h-6 w-11 rounded-full transition-colors ${value ? "bg-brand-500" : "bg-brand-200"}`, children: /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: `absolute top-0.5 size-5 rounded-full bg-white shadow-sm transition-transform ${value ? "translate-x-5" : "translate-x-0.5"}` }) })
  ] });
}
function Field({
  label,
  children
}) {
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "mb-1.5 block text-xs font-semibold uppercase tracking-wider text-brand-900/60", children: label }),
    children
  ] });
}
function Input({
  value,
  onChange,
  type = "text",
  placeholder
}) {
  return /* @__PURE__ */ jsxRuntimeExports.jsx("input", { type, value, onChange: (e) => onChange(e.target.value), placeholder, className: "h-11 w-full rounded-xl border border-border bg-card px-3 text-sm focus:border-brand-500 focus:outline-none focus:ring-2 focus:ring-brand-500/20" });
}
function Textarea({
  value,
  onChange,
  rows = 3
}) {
  return /* @__PURE__ */ jsxRuntimeExports.jsx("textarea", { rows, value, onChange: (e) => onChange(e.target.value), className: "w-full rounded-xl border border-border bg-card px-3 py-2.5 text-sm leading-relaxed focus:border-brand-500 focus:outline-none focus:ring-2 focus:ring-brand-500/20 resize-none" });
}
export {
  SettingsPage as component
};
