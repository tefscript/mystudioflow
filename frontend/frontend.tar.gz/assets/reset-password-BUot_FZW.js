import { R as Route, B as useNavigate, r as reactExports, k as jsxRuntimeExports, L as Link, A as toast, c as authApi } from "./index-DU09WJwA.js";
import { C as CircleAlert } from "./circle-alert-D8zQxJLf.js";
import { C as CircleCheckBig, A as ArrowLeft } from "./circle-check-big-CX0zvIlR.js";
import { L as Lock } from "./lock-Bx4TvpHr.js";
import { L as LoaderCircle } from "./loader-circle-F4UN_tCW.js";
import "./createLucideIcon-DhMEA509.js";
function ResetPasswordPage() {
  const {
    token
  } = Route.useSearch();
  const navigate = useNavigate();
  const [password, setPassword] = reactExports.useState("");
  const [confirm, setConfirm] = reactExports.useState("");
  const [loading, setLoading] = reactExports.useState(false);
  const [done, setDone] = reactExports.useState(false);
  if (!token) {
    return /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex min-h-screen items-center justify-center bg-brand-50 px-4", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "w-full max-w-sm rounded-2xl border border-border bg-white p-8 text-center shadow-sm", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "mx-auto mb-4 flex size-14 items-center justify-center rounded-full bg-rose-100", children: /* @__PURE__ */ jsxRuntimeExports.jsx(CircleAlert, { className: "size-7 text-rose-600" }) }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("h2", { className: "font-serif text-xl font-semibold", children: "Link inválido" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "mt-2 text-sm text-brand-900/60", children: "Este link de redefinição é inválido ou expirou." }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(Link, { to: "/forgot-password", className: "mt-6 flex items-center justify-center gap-2 text-sm font-semibold text-brand-600 hover:underline", children: "Solicitar novo link" })
    ] }) });
  }
  const onSubmit = async (e) => {
    e.preventDefault();
    if (password.length < 6) {
      toast.error("A senha precisa ter pelo menos 6 caracteres");
      return;
    }
    if (password !== confirm) {
      toast.error("As senhas não coincidem");
      return;
    }
    setLoading(true);
    try {
      await authApi.resetPassword(token, password);
      setDone(true);
      setTimeout(() => navigate({
        to: "/"
      }), 3e3);
    } catch (err) {
      toast.error(err.message ?? "Link inválido ou expirado");
    } finally {
      setLoading(false);
    }
  };
  return /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex min-h-screen items-center justify-center bg-brand-50 px-4", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "w-full max-w-sm animate-float-in", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsxs(Link, { to: "/", className: "mb-10 flex items-center gap-3", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex size-10 items-center justify-center rounded-xl bg-brand-500 font-serif text-2xl italic text-white shadow-lg shadow-brand-500/30", children: "S" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "font-serif text-2xl font-semibold", children: "StudioFlow" })
    ] }),
    done ? /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "rounded-2xl border border-border bg-white p-8 text-center shadow-sm", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "mx-auto mb-4 flex size-14 items-center justify-center rounded-full bg-emerald-100", children: /* @__PURE__ */ jsxRuntimeExports.jsx(CircleCheckBig, { className: "size-7 text-emerald-600" }) }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("h2", { className: "font-serif text-2xl font-semibold", children: "Senha redefinida!" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "mt-2 text-sm text-brand-900/60", children: "Sua senha foi atualizada. Redirecionando para o login..." })
    ] }) : /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("h1", { className: "font-serif text-3xl font-semibold", children: "Nova senha" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "mt-2 text-brand-900/60", children: "Escolha uma nova senha para sua conta." }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("form", { onSubmit, className: "mt-8 space-y-5", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "mb-1.5 block text-xs font-semibold uppercase tracking-wider text-brand-900/60", children: "Nova senha" }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "relative", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(Lock, { className: "pointer-events-none absolute left-4 top-1/2 size-4 -translate-y-1/2 text-brand-900/40" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("input", { type: "password", value: password, onChange: (e) => setPassword(e.target.value), placeholder: "Mínimo 6 caracteres", autoFocus: true, className: "h-12 w-full rounded-xl border border-border bg-white pl-11 pr-4 text-sm placeholder:text-brand-900/30 focus:border-brand-500 focus:outline-none focus:ring-2 focus:ring-brand-500/20" })
          ] })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "mb-1.5 block text-xs font-semibold uppercase tracking-wider text-brand-900/60", children: "Confirmar nova senha" }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "relative", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(Lock, { className: "pointer-events-none absolute left-4 top-1/2 size-4 -translate-y-1/2 text-brand-900/40" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("input", { type: "password", value: confirm, onChange: (e) => setConfirm(e.target.value), placeholder: "Repita a senha", className: "h-12 w-full rounded-xl border border-border bg-white pl-11 pr-4 text-sm placeholder:text-brand-900/30 focus:border-brand-500 focus:outline-none focus:ring-2 focus:ring-brand-500/20" })
          ] })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("button", { type: "submit", disabled: loading, className: "flex h-12 w-full items-center justify-center gap-2 rounded-xl bg-brand-600 text-sm font-semibold text-white shadow-lg shadow-brand-600/20 transition-all hover:bg-brand-500 disabled:opacity-70", children: [
          loading ? /* @__PURE__ */ jsxRuntimeExports.jsx(LoaderCircle, { className: "size-4 animate-spin" }) : null,
          loading ? "Salvando..." : "Redefinir senha"
        ] })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs(Link, { to: "/", className: "mt-6 flex items-center justify-center gap-2 text-sm font-semibold text-brand-600 hover:underline", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(ArrowLeft, { className: "size-4" }),
        " Voltar ao login"
      ] })
    ] })
  ] }) });
}
export {
  ResetPasswordPage as component
};
