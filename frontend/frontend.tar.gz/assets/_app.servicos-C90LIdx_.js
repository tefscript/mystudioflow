import { r as reactExports, t as servicesApi, A as toast, k as jsxRuntimeExports } from "./index-DU09WJwA.js";
import { P as PageHeader, a as PrimaryButton, X } from "./AppShell-B-Yqm6fM.js";
import { L as LoaderCircle } from "./loader-circle-F4UN_tCW.js";
import { S as Sparkles } from "./sparkles-Czkx5i21.js";
import { P as Pencil, T as Trash2, C as Clock } from "./trash-2-Bw59hTNM.js";
import { D as DollarSign } from "./dollar-sign-cGTCU4qL.js";
import "./createLucideIcon-DhMEA509.js";
function ServicosPage() {
  const [list, setList] = reactExports.useState([]);
  const [loading, setLoading] = reactExports.useState(true);
  const [editing, setEditing] = reactExports.useState(null);
  const [open, setOpen] = reactExports.useState(false);
  reactExports.useEffect(() => {
    servicesApi.list().then(setList).catch(() => toast.error("Erro ao carregar serviços")).finally(() => setLoading(false));
  }, []);
  const groups = list.reduce((acc, s) => {
    (acc[s.category] ||= []).push(s);
    return acc;
  }, {});
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mx-auto max-w-7xl", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx(PageHeader, { title: "Serviços", subtitle: "Gerencie os serviços oferecidos no seu estúdio.", action: /* @__PURE__ */ jsxRuntimeExports.jsx(PrimaryButton, { onClick: () => {
      setEditing(null);
      setOpen(true);
    }, children: "Novo serviço" }) }),
    loading ? /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex items-center justify-center py-16 text-brand-900/40", children: /* @__PURE__ */ jsxRuntimeExports.jsx(LoaderCircle, { className: "size-6 animate-spin" }) }) : list.length === 0 ? /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "rounded-3xl border border-dashed border-border bg-card p-12 text-center", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "font-serif text-lg", children: "Nenhum serviço cadastrado" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "mt-1 text-sm text-brand-900/50", children: "Crie seu primeiro serviço clicando no botão acima." })
    ] }) : /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "space-y-8", children: Object.entries(groups).map(([cat, items]) => /* @__PURE__ */ jsxRuntimeExports.jsxs("section", { children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("h2", { className: "mb-4 flex items-center gap-2 font-serif text-lg font-semibold", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(Sparkles, { className: "size-4 text-brand-500" }),
        " ",
        cat
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3", children: items.map((s, i) => /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "group animate-float-in rounded-2xl border border-border bg-card p-5 shadow-sm transition-all hover:border-brand-300 hover:shadow-md", style: {
        animationDelay: `${i * 50}ms`
      }, children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mb-4 flex items-start justify-between", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: "font-serif text-lg font-semibold", children: s.name }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex gap-1 opacity-0 transition-opacity group-hover:opacity-100", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("button", { onClick: () => {
              setEditing(s);
              setOpen(true);
            }, className: "rounded-lg p-1.5 text-brand-600 hover:bg-brand-100", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Pencil, { className: "size-3.5" }) }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("button", { onClick: async () => {
              if (!confirm(`Remover "${s.name}"?`)) return;
              try {
                await servicesApi.delete(s.id);
                setList((prev) => prev.filter((x) => x.id !== s.id));
                toast.success("Serviço removido");
              } catch (err) {
                toast.error(err instanceof Error ? err.message : "Erro ao remover");
              }
            }, className: "rounded-lg p-1.5 text-destructive hover:bg-rose-50", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Trash2, { className: "size-3.5" }) })
          ] })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-1.5 text-sm text-brand-900/60", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(Clock, { className: "size-3.5" }),
            " ",
            s.duration,
            " min"
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-0.5 font-serif text-xl font-semibold text-brand-600", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(DollarSign, { className: "size-4" }),
            s.price.toLocaleString("pt-BR")
          ] })
        ] })
      ] }, s.id)) })
    ] }, cat)) }),
    open && /* @__PURE__ */ jsxRuntimeExports.jsx(ServiceModal, { service: editing, onClose: () => setOpen(false), onSave: (s) => {
      setList((prev) => {
        const exists = prev.find((x) => x.id === s.id);
        return exists ? prev.map((x) => x.id === s.id ? s : x) : [s, ...prev];
      });
      setOpen(false);
      toast.success(editing ? "Serviço atualizado!" : "Serviço criado!");
    } })
  ] });
}
function ServiceModal({
  service,
  onClose,
  onSave
}) {
  const PRESET_CATEGORIES = ["Cílios", "Sobrancelha", "Estética", "Perfuração", "Outros"];
  const [name, setName] = reactExports.useState(service?.name ?? "");
  const [category, setCategory] = reactExports.useState(service?.category ?? "Cílios");
  const [customCategory, setCustomCategory] = reactExports.useState(service && !PRESET_CATEGORIES.includes(service.category) ? service.category : "");
  const [duration, setDuration] = reactExports.useState(service?.duration ?? 60);
  const [price, setPrice] = reactExports.useState(service?.price ?? 100);
  const [loading, setLoading] = reactExports.useState(false);
  const effectiveCategory = category === "__custom__" ? customCategory.trim() : category;
  const submit = async (e) => {
    e.preventDefault();
    if (!name) {
      toast.error("Nome obrigatório");
      return;
    }
    setLoading(true);
    try {
      if (category === "__custom__" && !customCategory.trim()) {
        toast.error("Digite o nome da categoria");
        setLoading(false);
        return;
      }
      let saved;
      if (service) {
        saved = await servicesApi.update(service.id, {
          name,
          category: effectiveCategory,
          duration,
          price
        });
      } else {
        saved = await servicesApi.create({
          name,
          category: effectiveCategory,
          duration,
          price
        });
      }
      onSave(saved);
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Erro ao salvar serviço");
    } finally {
      setLoading(false);
    }
  };
  return /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "fixed inset-0 z-50 flex items-end justify-center bg-brand-900/40 backdrop-blur-sm md:items-center md:p-4", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "w-full max-w-md animate-float-in rounded-t-3xl bg-card p-6 shadow-2xl md:rounded-3xl md:p-8", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mb-6 flex items-start justify-between", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("h2", { className: "font-serif text-2xl font-semibold", children: service ? "Editar serviço" : "Novo serviço" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("button", { onClick: onClose, className: "rounded-xl p-2 hover:bg-brand-100", children: /* @__PURE__ */ jsxRuntimeExports.jsx(X, { className: "size-4" }) })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("form", { onSubmit: submit, className: "space-y-4", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(Field, { label: "Nome", children: /* @__PURE__ */ jsxRuntimeExports.jsx("input", { value: name, onChange: (e) => setName(e.target.value), placeholder: "Ex: Lash Lifting", className: "h-11 w-full rounded-xl border border-border bg-card px-3 text-sm focus:border-brand-500 focus:outline-none focus:ring-2 focus:ring-brand-500/20" }) }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs(Field, { label: "Categoria", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("select", { value: category, onChange: (e) => setCategory(e.target.value), className: "h-11 w-full rounded-xl border border-border bg-card px-3 text-sm focus:border-brand-500 focus:outline-none focus:ring-2 focus:ring-brand-500/20", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("option", { children: "Cílios" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("option", { children: "Sobrancelha" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("option", { children: "Estética" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("option", { children: "Perfuração" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("option", { children: "Outros" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "__custom__", children: "+ Nova categoria..." })
        ] }),
        category === "__custom__" && /* @__PURE__ */ jsxRuntimeExports.jsx("input", { autoFocus: true, value: customCategory, onChange: (e) => setCustomCategory(e.target.value), placeholder: "Nome da nova categoria", className: "mt-2 h-11 w-full rounded-xl border border-border bg-card px-3 text-sm focus:border-brand-500 focus:outline-none focus:ring-2 focus:ring-brand-500/20" })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid grid-cols-2 gap-3", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(Field, { label: "Duração (min)", children: /* @__PURE__ */ jsxRuntimeExports.jsx("input", { type: "number", min: 5, step: 5, value: duration, onChange: (e) => setDuration(Number(e.target.value)), className: "h-11 w-full rounded-xl border border-border bg-card px-3 text-sm focus:border-brand-500 focus:outline-none focus:ring-2 focus:ring-brand-500/20" }) }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(Field, { label: "Preço (R$)", children: /* @__PURE__ */ jsxRuntimeExports.jsx("input", { type: "number", min: 0, value: price, onChange: (e) => setPrice(Number(e.target.value)), className: "h-11 w-full rounded-xl border border-border bg-card px-3 text-sm focus:border-brand-500 focus:outline-none focus:ring-2 focus:ring-brand-500/20" }) })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex gap-3 pt-2", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("button", { type: "button", onClick: onClose, className: "h-11 flex-1 rounded-xl border border-border bg-card text-sm font-semibold hover:bg-brand-100", children: "Cancelar" }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("button", { type: "submit", disabled: loading, className: "flex h-11 flex-1 items-center justify-center gap-2 rounded-xl bg-brand-600 text-sm font-semibold text-white shadow-lg shadow-brand-600/20 hover:bg-brand-500 disabled:opacity-70", children: [
          loading && /* @__PURE__ */ jsxRuntimeExports.jsx(LoaderCircle, { className: "size-4 animate-spin" }),
          loading ? "Salvando..." : "Salvar"
        ] })
      ] })
    ] })
  ] }) });
}
function Field({
  label,
  children
}) {
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "mb-1.5 block text-xs font-semibold uppercase tracking-wider text-brand-900/60", children: label }),
    children
  ] });
}
export {
  ServicosPage as component
};
