import { r as reactExports, e as clientsApi, A as toast, k as jsxRuntimeExports } from "./index-DU09WJwA.js";
import { P as PageHeader, a as PrimaryButton, S as Search, X } from "./AppShell-B-Yqm6fM.js";
import "./mock-data-BwVATWgX.js";
import { c as createLucideIcon } from "./createLucideIcon-DhMEA509.js";
import { L as LoaderCircle } from "./loader-circle-F4UN_tCW.js";
import { M as MessageCircle } from "./message-circle-DV6-LHLJ.js";
import { P as Phone } from "./phone-ChYg33WA.js";
import { M as Mail } from "./mail-P57eSgpE.js";
import "./sparkles-Czkx5i21.js";
const __iconNode = [
  [
    "path",
    {
      d: "M10 20a1 1 0 0 0 .553.895l2 1A1 1 0 0 0 14 21v-7a2 2 0 0 1 .517-1.341L21.74 4.67A1 1 0 0 0 21 3H3a1 1 0 0 0-.742 1.67l7.225 7.989A2 2 0 0 1 10 14z",
      key: "sc7q7i"
    }
  ]
];
const Funnel = createLucideIcon("funnel", __iconNode);
function buildWhatsAppLink(phone, message) {
  const digits = (phone ?? "").replace(/\D/g, "");
  const withCountry = digits.length > 0 && digits.length <= 11 ? `55${digits}` : digits;
  return `https://wa.me/${withCountry}?text=${encodeURIComponent(message)}`;
}
function ClientesPage() {
  const [list, setList] = reactExports.useState([]);
  const [loading, setLoading] = reactExports.useState(true);
  const [q, setQ] = reactExports.useState("");
  const [open, setOpen] = reactExports.useState(false);
  const [selected, setSelected] = reactExports.useState(null);
  reactExports.useEffect(() => {
    clientsApi.list().then(setList).catch(() => toast.error("Erro ao carregar clientes")).finally(() => setLoading(false));
  }, []);
  const filtered = reactExports.useMemo(() => list.filter((c) => c.name.toLowerCase().includes(q.toLowerCase()) || c.phone.includes(q) || c.email?.toLowerCase().includes(q.toLowerCase())), [list, q]);
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mx-auto max-w-7xl", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx(PageHeader, { title: "Clientes", subtitle: `${list.length} clientes cadastradas`, action: /* @__PURE__ */ jsxRuntimeExports.jsx(PrimaryButton, { onClick: () => setOpen(true), children: "Nova cliente" }) }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mb-6 flex flex-col gap-3 sm:flex-row", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "relative flex-1", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(Search, { className: "pointer-events-none absolute left-4 top-1/2 size-4 -translate-y-1/2 text-brand-900/40" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("input", { value: q, onChange: (e) => setQ(e.target.value), placeholder: "Buscar por nome, telefone ou e-mail...", className: "h-12 w-full rounded-2xl border border-border bg-card pl-11 pr-4 text-sm focus:border-brand-500 focus:outline-none focus:ring-2 focus:ring-brand-500/20" })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("button", { className: "flex h-12 items-center justify-center gap-2 rounded-2xl border border-border bg-card px-5 text-sm font-semibold hover:bg-brand-100", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(Funnel, { className: "size-4" }),
        " Filtros"
      ] })
    ] }),
    loading ? /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex items-center justify-center py-16 text-brand-900/40", children: /* @__PURE__ */ jsxRuntimeExports.jsx(LoaderCircle, { className: "size-6 animate-spin" }) }) : filtered.length === 0 ? /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "rounded-3xl border border-dashed border-border bg-card p-12 text-center", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "font-serif text-lg", children: "Nenhuma cliente encontrada" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "mt-1 text-sm text-brand-900/50", children: "Tente outro termo de busca." })
    ] }) : /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "overflow-hidden rounded-3xl border border-border bg-card shadow-sm", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("table", { className: "w-full", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("thead", { children: /* @__PURE__ */ jsxRuntimeExports.jsxs("tr", { className: "border-b border-border bg-brand-50/50 text-left text-xs font-semibold uppercase tracking-wider text-brand-900/60", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("th", { className: "px-6 py-4", children: "Cliente" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("th", { className: "hidden px-6 py-4 md:table-cell", children: "Telefone" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("th", { className: "hidden px-6 py-4 lg:table-cell", children: "Observações" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("th", { className: "px-6 py-4 text-center", children: "Visitas" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("th", { className: "px-6 py-4" })
      ] }) }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("tbody", { children: filtered.map((c, i) => /* @__PURE__ */ jsxRuntimeExports.jsxs("tr", { className: "group border-b border-border/60 transition-colors last:border-b-0 hover:bg-brand-50/40 animate-float-in", style: {
        animationDelay: `${i * 30}ms`
      }, children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("td", { className: "px-6 py-4", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("button", { onClick: () => setSelected(c), className: "flex items-center gap-3 text-left", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex size-10 shrink-0 items-center justify-center rounded-full bg-brand-100 font-serif text-sm font-semibold text-brand-600", children: c.name.split(" ").map((n) => n[0]).slice(0, 2).join("") }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "font-semibold", children: c.name }),
            c.email && /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-brand-900/50", children: c.email })
          ] })
        ] }) }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("td", { className: "hidden px-6 py-4 text-sm text-brand-900/70 md:table-cell", children: c.phone }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("td", { className: "hidden max-w-xs px-6 py-4 lg:table-cell", children: /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "truncate text-sm text-brand-900/60", children: c.notes || "—" }) }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("td", { className: "px-6 py-4 text-center", children: /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "rounded-full bg-brand-100 px-3 py-1 text-xs font-bold text-brand-600", children: c.visits }) }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("td", { className: "px-6 py-4 text-right", children: /* @__PURE__ */ jsxRuntimeExports.jsx("a", { href: buildWhatsAppLink(c.phone, `Oi, ${c.name.split(" ")[0]}! 💕`), target: "_blank", rel: "noreferrer", className: "rounded-lg p-2 text-brand-600 opacity-0 transition-opacity group-hover:opacity-100 hover:bg-brand-100 inline-flex", children: /* @__PURE__ */ jsxRuntimeExports.jsx(MessageCircle, { className: "size-4" }) }) })
      ] }, c.id)) })
    ] }) }),
    open && /* @__PURE__ */ jsxRuntimeExports.jsx(ClientModal, { onClose: () => setOpen(false), onSave: (c) => {
      setList((prev) => [c, ...prev]);
      setOpen(false);
      toast.success("Cliente cadastrada!");
    } }),
    selected && /* @__PURE__ */ jsxRuntimeExports.jsx(ClientDetail, { client: selected, onClose: () => setSelected(null), onDelete: (id) => {
      setList((prev) => prev.filter((c) => c.id !== id));
      setSelected(null);
    } })
  ] });
}
function ClientModal({
  onClose,
  onSave
}) {
  const [name, setName] = reactExports.useState("");
  const [phone, setPhone] = reactExports.useState("");
  const [email, setEmail] = reactExports.useState("");
  const [notes, setNotes] = reactExports.useState("");
  const [loading, setLoading] = reactExports.useState(false);
  const submit = async (e) => {
    e.preventDefault();
    if (!name || !phone) {
      toast.error("Nome e telefone são obrigatórios");
      return;
    }
    setLoading(true);
    try {
      const client = await clientsApi.create({
        name,
        phone,
        email: email || void 0,
        notes: notes || void 0
      });
      onSave(client);
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Erro ao cadastrar cliente");
    } finally {
      setLoading(false);
    }
  };
  return /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "fixed inset-0 z-50 flex items-end justify-center bg-brand-900/40 backdrop-blur-sm md:items-center md:p-4", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "w-full max-w-md animate-float-in rounded-t-3xl bg-card p-6 shadow-2xl md:rounded-3xl md:p-8", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mb-6 flex items-start justify-between", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("h2", { className: "font-serif text-2xl font-semibold", children: "Nova cliente" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("button", { onClick: onClose, className: "rounded-xl p-2 hover:bg-brand-100", children: /* @__PURE__ */ jsxRuntimeExports.jsx(X, { className: "size-4" }) })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("form", { onSubmit: submit, className: "space-y-4", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(Input, { label: "Nome completo", value: name, onChange: setName, placeholder: "Ex: Isabel Rocha" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(Input, { label: "Telefone", value: phone, onChange: setPhone, placeholder: "(11) 99999-9999" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(Input, { label: "E-mail (opcional)", value: email, onChange: setEmail, type: "email", placeholder: "email@exemplo.com" }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "mb-1.5 block text-xs font-semibold uppercase tracking-wider text-brand-900/60", children: "Observações" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("textarea", { value: notes, onChange: (e) => setNotes(e.target.value), rows: 3, placeholder: "Preferências, alergias, indicação...", className: "w-full rounded-xl border border-border bg-card p-3 text-sm focus:border-brand-500 focus:outline-none focus:ring-2 focus:ring-brand-500/20" })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex gap-3 pt-2", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("button", { type: "button", onClick: onClose, className: "h-11 flex-1 rounded-xl border border-border bg-card text-sm font-semibold hover:bg-brand-100", children: "Cancelar" }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("button", { type: "submit", disabled: loading, className: "flex h-11 flex-1 items-center justify-center gap-2 rounded-xl bg-brand-600 text-sm font-semibold text-white shadow-lg shadow-brand-600/20 hover:bg-brand-500 disabled:opacity-70", children: [
          loading && /* @__PURE__ */ jsxRuntimeExports.jsx(LoaderCircle, { className: "size-4 animate-spin" }),
          loading ? "Salvando..." : "Salvar"
        ] })
      ] })
    ] })
  ] }) });
}
function ClientDetail({
  client,
  onClose,
  onDelete
}) {
  const [deleting, setDeleting] = reactExports.useState(false);
  const handleDelete = async () => {
    if (!confirm(`Remover ${client.name}?`)) return;
    setDeleting(true);
    try {
      await clientsApi.delete(client.id);
      toast.success("Cliente removida");
      onDelete(client.id);
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Erro ao remover");
    } finally {
      setDeleting(false);
    }
  };
  return /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "fixed inset-0 z-50 flex items-end justify-center bg-brand-900/40 backdrop-blur-sm md:items-center md:p-4", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "w-full max-w-md animate-float-in rounded-t-3xl bg-card p-8 shadow-2xl md:rounded-3xl", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mb-6 flex items-start justify-between", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-4", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex size-14 items-center justify-center rounded-full bg-brand-100 font-serif text-xl font-semibold text-brand-600", children: client.name.split(" ").map((n) => n[0]).slice(0, 2).join("") }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("h2", { className: "font-serif text-xl font-semibold", children: client.name }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { className: "text-sm text-brand-900/50", children: [
            client.visits,
            " visitas"
          ] })
        ] })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("button", { onClick: onClose, className: "rounded-xl p-2 hover:bg-brand-100", children: /* @__PURE__ */ jsxRuntimeExports.jsx(X, { className: "size-4" }) })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-3", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-3 rounded-xl bg-brand-50 p-4", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(Phone, { className: "size-4 text-brand-600" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-sm", children: client.phone })
      ] }),
      client.email && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-3 rounded-xl bg-brand-50 p-4", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(Mail, { className: "size-4 text-brand-600" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-sm", children: client.email })
      ] }),
      client.notes && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "rounded-xl bg-brand-50 p-4", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "mb-1 text-xs font-semibold uppercase tracking-wider text-brand-900/60", children: "Observações" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-sm leading-relaxed", children: client.notes })
      ] })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mt-6 flex gap-3", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("a", { href: buildWhatsAppLink(client.phone, `Oi, ${client.name.split(" ")[0]}! 💕`), target: "_blank", rel: "noreferrer", className: "flex h-11 flex-1 items-center justify-center gap-2 rounded-xl bg-emerald-600 text-sm font-semibold text-white shadow-lg shadow-emerald-600/20 hover:bg-emerald-500", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(MessageCircle, { className: "size-4" }),
        " Enviar WhatsApp"
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("button", { onClick: handleDelete, disabled: deleting, className: "flex h-11 items-center justify-center gap-2 rounded-xl border border-rose-200 bg-rose-50 px-4 text-sm font-semibold text-rose-600 hover:bg-rose-100 disabled:opacity-70", children: deleting ? /* @__PURE__ */ jsxRuntimeExports.jsx(LoaderCircle, { className: "size-4 animate-spin" }) : "Remover" })
    ] })
  ] }) });
}
function Input({
  label,
  value,
  onChange,
  type = "text",
  placeholder
}) {
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "mb-1.5 block text-xs font-semibold uppercase tracking-wider text-brand-900/60", children: label }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("input", { type, value, onChange: (e) => onChange(e.target.value), placeholder, className: "h-11 w-full rounded-xl border border-border bg-card px-3 text-sm focus:border-brand-500 focus:outline-none focus:ring-2 focus:ring-brand-500/20" })
  ] });
}
export {
  ClientesPage as component
};
