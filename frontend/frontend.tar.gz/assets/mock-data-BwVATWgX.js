(/* @__PURE__ */ new Date()).toISOString().slice(0, 10);
new Date(Date.now() + 864e5).toISOString().slice(0, 10);
const statusLabels = {
  confirmado: "Confirmado",
  aguardando: "Aguardando",
  concluido: "Concluído",
  cancelado: "Cancelado"
};
const statusStyles = {
  confirmado: "bg-emerald-500 text-white",
  aguardando: "bg-sky-500 text-white",
  concluido: "bg-brand-500 text-white",
  cancelado: "bg-rose-400 text-white"
};
export {
  statusStyles as a,
  statusLabels as s
};
