import { k as jsxRuntimeExports, O as Outlet, T as Toaster } from "./index-DU09WJwA.js";
import { A as AppShell } from "./AppShell-B-Yqm6fM.js";
import "./createLucideIcon-DhMEA509.js";
import "./sparkles-Czkx5i21.js";
function AppLayout() {
  return /* @__PURE__ */ jsxRuntimeExports.jsxs(AppShell, { children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx(Outlet, {}),
    /* @__PURE__ */ jsxRuntimeExports.jsx(Toaster, { position: "top-right" })
  ] });
}
export {
  AppLayout as component
};
