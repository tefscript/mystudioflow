import { r as reactExports, k as jsxRuntimeExports, L as Link, A as toast, c as authApi } from "./index-DU09WJwA.js";
import { C as CircleCheckBig, A as ArrowLeft } from "./circle-check-big-CX0zvIlR.js";
import { M as Mail } from "./mail-P57eSgpE.js";
import { L as LoaderCircle } from "./loader-circle-F4UN_tCW.js";
import "./createLucideIcon-DhMEA509.js";
function ForgotPasswordPage() {
  const [email, setEmail] = reactExports.useState("");
  const [loading, setLoading] = reactExports.useState(false);
  const [sent, setSent] = reactExports.useState(false);
  const onSubmit = async (e) => {
    e.preventDefault();
    if (!email) {
      toast.error("Informe seu e-mail");
      return;
    }
    setLoading(true);
    try {
      await authApi.forgotPassword(email);
      setSent(true);
    } catch {
      toast.error("Erro ao enviar e-mail. Tente novamente.");
    } finally {
      setLoading(false);
    }
  };
  return /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex min-h-screen items-center justify-center bg-brand-50 px-4", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "w-full max-w-sm animate-float-in", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsxs(Link, { to: "/", className: "mb-10 flex items-center gap-3", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex size-10 items-center justify-center rounded-xl bg-brand-500 font-serif text-2xl italic text-white shadow-lg shadow-brand-500/30", children: "S" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "font-serif text-2xl font-semibold", children: "StudioFlow" })
    ] }),
    sent ? /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "rounded-2xl border border-border bg-white p-8 text-center shadow-sm", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "mx-auto mb-4 flex size-14 items-center justify-center rounded-full bg-emerald-100", children: /* @__PURE__ */ jsxRuntimeExports.jsx(CircleCheckBig, { className: "size-7 text-emerald-600" }) }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("h2", { className: "font-serif text-2xl font-semibold", children: "E-mail enviado!" }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { className: "mt-2 text-sm text-brand-900/60", children: [
        "Se ",
        /* @__PURE__ */ jsxRuntimeExports.jsx("strong", { children: email }),
        " estiver cadastrado, você receberá as instruções para redefinir sua senha."
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "mt-2 text-xs text-brand-900/40", children: "O link expira em 1 hora." }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs(Link, { to: "/", className: "mt-6 flex items-center justify-center gap-2 text-sm font-semibold text-brand-600 hover:underline", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(ArrowLeft, { className: "size-4" }),
        " Voltar ao login"
      ] })
    ] }) : /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("h1", { className: "font-serif text-3xl font-semibold", children: "Esqueci minha senha" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "mt-2 text-brand-900/60", children: "Informe seu e-mail e enviaremos um link para redefinir sua senha." }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("form", { onSubmit, className: "mt-8 space-y-5", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "mb-1.5 block text-xs font-semibold uppercase tracking-wider text-brand-900/60", children: "E-mail" }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "relative", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(Mail, { className: "pointer-events-none absolute left-4 top-1/2 size-4 -translate-y-1/2 text-brand-900/40" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("input", { type: "email", value: email, onChange: (e) => setEmail(e.target.value), placeholder: "seu@email.com", autoFocus: true, className: "h-12 w-full rounded-xl border border-border bg-white pl-11 pr-4 text-sm placeholder:text-brand-900/30 focus:border-brand-500 focus:outline-none focus:ring-2 focus:ring-brand-500/20" })
          ] })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("button", { type: "submit", disabled: loading, className: "flex h-12 w-full items-center justify-center gap-2 rounded-xl bg-brand-600 text-sm font-semibold text-white shadow-lg shadow-brand-600/20 transition-all hover:bg-brand-500 disabled:opacity-70", children: [
          loading ? /* @__PURE__ */ jsxRuntimeExports.jsx(LoaderCircle, { className: "size-4 animate-spin" }) : null,
          loading ? "Enviando..." : "Enviar link de redefinição"
        ] })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs(Link, { to: "/", className: "mt-6 flex items-center justify-center gap-2 text-sm font-semibold text-brand-600 hover:underline", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(ArrowLeft, { className: "size-4" }),
        " Voltar ao login"
      ] })
    ] })
  ] }) });
}
export {
  ForgotPasswordPage as component
};
